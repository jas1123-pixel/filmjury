# FilmJury — Short Film Contest Submission and Scoring

A Spring Boot + Spring Data JPA backend for a college short-film contest.
Teams submit entries, judges score them independently against a fixed set
of criteria, and the app computes an average score per entry and a ranked
leaderboard.

Built to fit the existing `java-dbms-project` skeleton
(`com.example:project1`, Java 17, Maven, Spring Boot, Spring Data JPA,
MySQL driver, springdoc-openapi for Swagger).

## 1. Project structure

```
src/main/java/com/example/project1/
├── Project1Application.java
├── model/          Entry, Judge, Criterion, ScoreCard  (JPA entities)
├── repository/     Spring Data JPA repositories
├── dto/            Request/response objects
├── service/        Business rules (EntryService, JudgeService,
│                   CriterionService, ScoreCardService, ScoringService)
├── controller/     REST endpoints
└── exception/      Custom exceptions + a single @RestControllerAdvice
src/main/resources/
├── application.properties   H2 by default; MySQL block ready to uncomment
├── data.sql                 seeds 4 fixed criteria on every startup
└── static/                  the web UI (index.html, style.css, app.js)
```

## 2. Database design

| Entity      | Key fields                                   | Relationships |
|-------------|-----------------------------------------------|----------------|
| `Entry`     | title, genre, videoLink                       | `@ManyToMany` assigned judges (join table `entry_judge_assignment`); owns its `ScoreCard`s |
| `Judge`     | name, email (unique)                          | `@ManyToMany` (inverse side) assigned entries; owns its `ScoreCard`s |
| `Criterion` | name (unique), description                    | referenced by `ScoreCard` |
| `ScoreCard` | score (0–10), comments, submittedAt           | `@ManyToOne` to Entry, Judge and Criterion. **Unique constraint on (entry_id, judge_id, criterion_id)** — a judge scores each criterion for an entry exactly once. All of a judge's `ScoreCard` rows for one entry together form that judge's "scorecard". |

`ScoreCard` is the entity that "owns" the relationship to both `Entry` and
`Judge` (it holds the foreign keys), matching the note in the spec about
which entity should reference/own another.

## 3. Business rules — where they're enforced

Both rules below are enforced in the **service layer**
(`ScoreCardService`), not only via the database's unique constraint, so a
bad request is rejected immediately with a clear message:

1. **An entry's final score is the average across all judges who scored
   it.** `ScoringService.computeEntryScore()` first averages each judge's
   own criterion scores, then averages those per-judge averages across
   every judge who submitted — see `ScoringService`.
2. **A judge can submit only one scorecard per entry.**
   `ScoreCardService.submitScoreCard()` checks
   `scoreCardRepository.existsByEntryIdAndJudgeId(...)` before saving
   anything, and throws `DuplicateScoreCardException` → **HTTP 409** with a
   clear message if the judge already scored that entry.

## 4. Running it

Requires JDK 17 and Maven (or use the `mvnw`/`mvnw.cmd` wrapper already in
your repo).

```bash
mvn spring-boot:run
```

The app starts on `http://localhost:8080` using an **in-memory H2**
database — no setup needed. Data resets every restart.

- **Web UI** (a small static frontend for the whole workflow — submit
  entries, register judges, add criteria, assign judges, submit
  scorecards, view the leaderboard): `http://localhost:8080/`
  (served from `src/main/resources/static/` — `index.html`, `style.css`,
  `app.js` — plain HTML/CSS/JS calling the REST API with `fetch`, no
  build step required)
- Swagger UI (try every endpoint directly):
  `http://localhost:8080/swagger-ui.html`
- H2 console: `http://localhost:8080/h2-console`
  (JDBC URL `jdbc:h2:mem:filmjury`, user `sa`, no password)

To point at MySQL instead, open `application.properties`, comment out the
H2 block and uncomment the MySQL block (update the username/password),
then create the `filmjury` schema — `spring.jpa.hibernate.ddl-auto=update`
will create the tables for you.

Four fixed criteria (`Story`, `Direction`, `Cinematography`, `Editing`)
are seeded automatically on every startup via `data.sql`.

## 5. API reference

### Entries
| Method | Path | Description |
|---|---|---|
| POST | `/api/entries` | Submit a new entry `{title, genre, videoLink}` |
| GET | `/api/entries` | List all entries |
| GET | `/api/entries/{entryId}` | Get one entry |
| PUT | `/api/entries/{entryId}` | Update an entry |
| DELETE | `/api/entries/{entryId}` | Delete an entry |
| POST | `/api/entries/{entryId}/judges/{judgeId}` | Assign a judge to review this entry |
| DELETE | `/api/entries/{entryId}/judges/{judgeId}` | Remove that assignment |

### Judges
| Method | Path | Description |
|---|---|---|
| POST | `/api/judges` | Register a judge `{name, email}` |
| GET | `/api/judges` | List all judges |
| GET | `/api/judges/{judgeId}` | Get one judge |
| PUT | `/api/judges/{judgeId}` | Update a judge |
| DELETE | `/api/judges/{judgeId}` | Delete a judge |

### Criteria
| Method | Path | Description |
|---|---|---|
| POST | `/api/criteria` | Add a criterion `{name, description}` |
| GET | `/api/criteria` | List all criteria |
| GET/PUT/DELETE | `/api/criteria/{criterionId}` | Get / update / delete one |

### Scorecards
| Method | Path | Description |
|---|---|---|
| POST | `/api/entries/{entryId}/judges/{judgeId}/scorecards` | Submit a full scorecard (one score per criterion). **409** if this judge already scored this entry. |
| GET | `/api/entries/{entryId}/scorecards` | All scorecard lines for an entry, every judge |
| GET | `/api/entries/{entryId}/judges/{judgeId}/scorecards` | One judge's scorecard for an entry |

### Scoring & leaderboard
| Method | Path | Description |
|---|---|---|
| GET | `/api/entries/{entryId}/score` | Entry's computed final score + per-judge breakdown |
| GET | `/api/leaderboard` | All entries ranked by final score, highest first. Optional `?page=&size=` |

## 6. Try it end-to-end (curl)

```bash
# 1. Create an entry
curl -s -X POST localhost:8080/api/entries -H "Content-Type: application/json" \
  -d '{"title":"The Last Reel","genre":"Drama","videoLink":"https://example.com/v1"}'

# 2. Register two judges
curl -s -X POST localhost:8080/api/judges -H "Content-Type: application/json" \
  -d '{"name":"Asha Rao","email":"asha@example.com"}'
curl -s -X POST localhost:8080/api/judges -H "Content-Type: application/json" \
  -d '{"name":"Vikram Iyer","email":"vikram@example.com"}'

# 3. Assign both judges to entry 1
curl -s -X POST localhost:8080/api/entries/1/judges/1
curl -s -X POST localhost:8080/api/entries/1/judges/2

# 4. Judge 1 submits a scorecard (criteria 1-4 were seeded by data.sql)
curl -s -X POST localhost:8080/api/entries/1/judges/1/scorecards \
  -H "Content-Type: application/json" \
  -d '{"scores":[{"criterionId":1,"score":8},{"criterionId":2,"score":7.5},
                  {"criterionId":3,"score":9},{"criterionId":4,"score":8}]}'

# 5. Same judge tries again -> 409 Conflict, clear error message
curl -s -X POST localhost:8080/api/entries/1/judges/1/scorecards \
  -H "Content-Type: application/json" \
  -d '{"scores":[{"criterionId":1,"score":5}]}'

# 6. Entry's computed score so far
curl -s localhost:8080/api/entries/1/score

# 7. Leaderboard
curl -s localhost:8080/api/leaderboard
```

Or skip curl entirely and use the Swagger UI at
`http://localhost:8080/swagger-ui.html`, or import the endpoints into
Postman.

## 7. Validation & error handling

Every 4xx/5xx response has the same shape (via `GlobalExceptionHandler`):

```json
{
  "timestamp": "...",
  "status": 400,
  "error": "Validation Failed",
  "message": "One or more fields are invalid",
  "fieldErrors": { "score": "score must be at most 10" }
}
```

- `400` — bean-validation failures (`@NotBlank`, `@DecimalMin/Max`, missing
  fields) and business-rule violations like a duplicate criterion in one
  submission
- `404` — entry/judge/criterion id not found
- `409` — judge already submitted a scorecard for this entry
- `500` — anything unexpected (caught, never a raw stack trace)

## 8. "Go further" ideas already included

- **Notification on submission**: `ScoreCardService` logs to the console
  every time a scorecard is submitted (swap for email/websocket easily).
- **Pagination**: `/api/leaderboard?page=0&size=10`.

Ideas left for you to extend further: role-based auth for judges vs.
admins, criterion weighting, email notifications instead of console logs,
and sorting/filtering on `GET /api/entries`.
