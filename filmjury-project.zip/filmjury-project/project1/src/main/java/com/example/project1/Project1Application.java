package com.example.project1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * FilmJury - Short Film Contest Submission and Scoring.
 *
 * Run with: mvn spring-boot:run
 * Swagger UI: http://localhost:8080/swagger-ui.html
 * H2 console: http://localhost:8080/h2-console
 */
@SpringBootApplication
public class Project1Application {
    public static void main(String[] args) {
        SpringApplication.run(Project1Application.class, args);
    }
}
