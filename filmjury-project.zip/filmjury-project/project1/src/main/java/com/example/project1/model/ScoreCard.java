package com.example.project1.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * One judge's score for one entry against one criterion.
 * The combination (entry, judge, criterion) is unique: a judge scores each
 * criterion for a given entry exactly once, which is what makes up that
 * judge's single "scorecard" for the entry.
 */
@Entity
@Table(
        name = "score_card",
        uniqueConstraints = @UniqueConstraint(
                name = "uk_entry_judge_criterion",
                columnNames = {"entry_id", "judge_id", "criterion_id"}
        )
)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ScoreCard {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "entry_id", nullable = false)
    private Entry entry;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "judge_id", nullable = false)
    private Judge judge;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "criterion_id", nullable = false)
    private Criterion criterion;

    @NotNull(message = "score is required")
    @DecimalMin(value = "0.0", message = "score must be at least 0")
    @DecimalMax(value = "10.0", message = "score must be at most 10")
    @Column(nullable = false)
    private Double score;

    @Column(length = 1000)
    private String comments;

    @Builder.Default
    @Column(nullable = false, updatable = false)
    private LocalDateTime submittedAt = LocalDateTime.now();
}
