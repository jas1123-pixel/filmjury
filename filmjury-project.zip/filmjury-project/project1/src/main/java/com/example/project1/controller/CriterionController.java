package com.example.project1.controller;

import com.example.project1.dto.CriterionRequest;
import com.example.project1.model.Criterion;
import com.example.project1.service.CriterionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Criteria", description = "Fixed judging criteria (Story, Direction, Cinematography, Editing)")
@RestController
@RequestMapping("/api/criteria")
@RequiredArgsConstructor
public class CriterionController {

    private final CriterionService criterionService;

    @Operation(summary = "Add a new judging criterion")
    @PostMapping
    public ResponseEntity<Criterion> createCriterion(@Valid @RequestBody CriterionRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(criterionService.createCriterion(request));
    }

    @Operation(summary = "List all judging criteria")
    @GetMapping
    public List<Criterion> getAllCriteria() {
        return criterionService.getAllCriteria();
    }

    @Operation(summary = "Get one criterion by id")
    @GetMapping("/{criterionId}")
    public Criterion getCriterion(@PathVariable Long criterionId) {
        return criterionService.getCriterionOrThrow(criterionId);
    }

    @Operation(summary = "Update a criterion")
    @PutMapping("/{criterionId}")
    public Criterion updateCriterion(@PathVariable Long criterionId, @Valid @RequestBody CriterionRequest request) {
        return criterionService.updateCriterion(criterionId, request);
    }

    @Operation(summary = "Delete a criterion")
    @DeleteMapping("/{criterionId}")
    public ResponseEntity<Void> deleteCriterion(@PathVariable Long criterionId) {
        criterionService.deleteCriterion(criterionId);
        return ResponseEntity.noContent().build();
    }
}
