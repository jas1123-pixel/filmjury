package com.example.project1.service;

import com.example.project1.dto.CriterionRequest;
import com.example.project1.exception.ResourceNotFoundException;
import com.example.project1.model.Criterion;
import com.example.project1.repository.CriterionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CriterionService {

    private final CriterionRepository criterionRepository;

    public Criterion createCriterion(CriterionRequest request) {
        Criterion criterion = Criterion.builder()
                .name(request.getName())
                .description(request.getDescription())
                .build();
        return criterionRepository.save(criterion);
    }

    public List<Criterion> getAllCriteria() {
        return criterionRepository.findAll();
    }

    public Criterion getCriterionOrThrow(Long criterionId) {
        return criterionRepository.findById(criterionId)
                .orElseThrow(() -> new ResourceNotFoundException("Criterion not found with id " + criterionId));
    }

    public Criterion updateCriterion(Long criterionId, CriterionRequest request) {
        Criterion criterion = getCriterionOrThrow(criterionId);
        criterion.setName(request.getName());
        criterion.setDescription(request.getDescription());
        return criterionRepository.save(criterion);
    }

    public void deleteCriterion(Long criterionId) {
        Criterion criterion = getCriterionOrThrow(criterionId);
        criterionRepository.delete(criterion);
    }
}
