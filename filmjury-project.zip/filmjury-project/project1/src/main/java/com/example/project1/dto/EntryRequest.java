package com.example.project1.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EntryRequest {

    @NotBlank(message = "title is required")
    private String title;

    @NotBlank(message = "genre is required")
    private String genre;

    @NotBlank(message = "videoLink is required")
    private String videoLink;
}
