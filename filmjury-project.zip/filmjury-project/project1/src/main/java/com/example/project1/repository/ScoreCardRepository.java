package com.example.project1.repository;

import com.example.project1.model.ScoreCard;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ScoreCardRepository extends JpaRepository<ScoreCard, Long> {

    List<ScoreCard> findByEntryId(Long entryId);

    List<ScoreCard> findByEntryIdAndJudgeId(Long entryId, Long judgeId);

    boolean existsByEntryIdAndJudgeId(Long entryId, Long judgeId);

    void deleteByEntryIdAndJudgeId(Long entryId, Long judgeId);
}
