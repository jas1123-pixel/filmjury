package com.example.project1.service;

import com.example.project1.dto.CriterionScoreRequest;
import com.example.project1.dto.ScoreCardResponse;
import com.example.project1.dto.ScoreCardSubmissionRequest;
import com.example.project1.exception.DuplicateScoreCardException;
import com.example.project1.exception.InvalidRequestException;
import com.example.project1.model.Criterion;
import com.example.project1.model.Entry;
import com.example.project1.model.Judge;
import com.example.project1.model.ScoreCard;
import com.example.project1.repository.ScoreCardRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Owns the "a judge submits one scorecard per entry" business rule.
 * This is enforced HERE in the service layer -- not only via the database's
 * unique constraint -- so a duplicate or invalid submission is rejected
 * immediately with a clear error message rather than silently failing or
 * corrupting data.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ScoreCardService {

    private final ScoreCardRepository scoreCardRepository;
    private final EntryService entryService;
    private final JudgeService judgeService;
    private final CriterionService criterionService;

    @Transactional
    public List<ScoreCardResponse> submitScoreCard(Long entryId, Long judgeId, ScoreCardSubmissionRequest request) {
        Entry entry = entryService.getEntryOrThrow(entryId);
        Judge judge = judgeService.getJudgeOrThrow(judgeId);

        // Business rule: a judge can submit only one scorecard per entry.
        if (scoreCardRepository.existsByEntryIdAndJudgeId(entryId, judgeId)) {
            throw new DuplicateScoreCardException(
                    "Judge " + judgeId + " has already submitted a scorecard for entry " + entryId);
        }

        List<CriterionScoreRequest> scores = request.getScores();

        long distinctCriteria = scores.stream().map(CriterionScoreRequest::getCriterionId).distinct().count();
        if (distinctCriteria != scores.size()) {
            throw new InvalidRequestException("Each criterion may only be scored once per scorecard");
        }

        LocalDateTime now = LocalDateTime.now();
        List<ScoreCard> toSave = scores.stream().map(line -> {
            Criterion criterion = criterionService.getCriterionOrThrow(line.getCriterionId());
            return ScoreCard.builder()
                    .entry(entry)
                    .judge(judge)
                    .criterion(criterion)
                    .score(line.getScore())
                    .comments(line.getComments())
                    .submittedAt(now)
                    .build();
        }).collect(Collectors.toList());

        List<ScoreCard> saved = scoreCardRepository.saveAll(toSave);

        // "Go further" idea: notify (here, a console log) whenever a scorecard is submitted.
        log.info("Judge '{}' (id={}) submitted a scorecard for entry '{}' (id={}) with {} criterion scores",
                judge.getName(), judge.getId(), entry.getTitle(), entry.getId(), saved.size());

        return saved.stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<ScoreCardResponse> getScoreCardsForEntry(Long entryId) {
        entryService.getEntryOrThrow(entryId);
        return scoreCardRepository.findByEntryId(entryId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<ScoreCardResponse> getScoreCardForJudgeOnEntry(Long entryId, Long judgeId) {
        entryService.getEntryOrThrow(entryId);
        judgeService.getJudgeOrThrow(judgeId);
        return scoreCardRepository.findByEntryIdAndJudgeId(entryId, judgeId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    private ScoreCardResponse toResponse(ScoreCard sc) {
        return ScoreCardResponse.builder()
                .id(sc.getId())
                .entryId(sc.getEntry().getId())
                .judgeId(sc.getJudge().getId())
                .judgeName(sc.getJudge().getName())
                .criterionId(sc.getCriterion().getId())
                .criterionName(sc.getCriterion().getName())
                .score(sc.getScore())
                .comments(sc.getComments())
                .submittedAt(sc.getSubmittedAt())
                .build();
    }
}
