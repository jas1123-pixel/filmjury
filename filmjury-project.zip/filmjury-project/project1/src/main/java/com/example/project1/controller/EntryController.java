package com.example.project1.controller;

import com.example.project1.dto.EntryRequest;
import com.example.project1.model.Entry;
import com.example.project1.service.EntryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Entries", description = "Film entries submitted to the contest")
@RestController
@RequestMapping("/api/entries")
@RequiredArgsConstructor
public class EntryController {

    private final EntryService entryService;

    @Operation(summary = "Submit a new film entry")
    @PostMapping
    public ResponseEntity<Entry> createEntry(@Valid @RequestBody EntryRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(entryService.createEntry(request));
    }

    @Operation(summary = "List all entries")
    @GetMapping
    public List<Entry> getAllEntries() {
        return entryService.getAllEntries();
    }

    @Operation(summary = "Get one entry by id")
    @GetMapping("/{entryId}")
    public Entry getEntry(@PathVariable Long entryId) {
        return entryService.getEntryOrThrow(entryId);
    }

    @Operation(summary = "Update an entry")
    @PutMapping("/{entryId}")
    public Entry updateEntry(@PathVariable Long entryId, @Valid @RequestBody EntryRequest request) {
        return entryService.updateEntry(entryId, request);
    }

    @Operation(summary = "Delete an entry")
    @DeleteMapping("/{entryId}")
    public ResponseEntity<Void> deleteEntry(@PathVariable Long entryId) {
        entryService.deleteEntry(entryId);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Assign a judge to review this entry")
    @PostMapping("/{entryId}/judges/{judgeId}")
    public Entry assignJudge(@PathVariable Long entryId, @PathVariable Long judgeId) {
        return entryService.assignJudge(entryId, judgeId);
    }

    @Operation(summary = "Remove a judge's assignment to this entry")
    @DeleteMapping("/{entryId}/judges/{judgeId}")
    public ResponseEntity<Void> unassignJudge(@PathVariable Long entryId, @PathVariable Long judgeId) {
        entryService.unassignJudge(entryId, judgeId);
        return ResponseEntity.noContent().build();
    }
}
