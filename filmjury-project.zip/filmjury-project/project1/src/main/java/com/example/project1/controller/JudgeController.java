package com.example.project1.controller;

import com.example.project1.dto.JudgeRequest;
import com.example.project1.model.Judge;
import com.example.project1.service.JudgeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Judges", description = "Contest judges")
@RestController
@RequestMapping("/api/judges")
@RequiredArgsConstructor
public class JudgeController {

    private final JudgeService judgeService;

    @Operation(summary = "Register a new judge")
    @PostMapping
    public ResponseEntity<Judge> createJudge(@Valid @RequestBody JudgeRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(judgeService.createJudge(request));
    }

    @Operation(summary = "List all judges")
    @GetMapping
    public List<Judge> getAllJudges() {
        return judgeService.getAllJudges();
    }

    @Operation(summary = "Get one judge by id")
    @GetMapping("/{judgeId}")
    public Judge getJudge(@PathVariable Long judgeId) {
        return judgeService.getJudgeOrThrow(judgeId);
    }

    @Operation(summary = "Update a judge")
    @PutMapping("/{judgeId}")
    public Judge updateJudge(@PathVariable Long judgeId, @Valid @RequestBody JudgeRequest request) {
        return judgeService.updateJudge(judgeId, request);
    }

    @Operation(summary = "Delete a judge")
    @DeleteMapping("/{judgeId}")
    public ResponseEntity<Void> deleteJudge(@PathVariable Long judgeId) {
        judgeService.deleteJudge(judgeId);
        return ResponseEntity.noContent().build();
    }
}
