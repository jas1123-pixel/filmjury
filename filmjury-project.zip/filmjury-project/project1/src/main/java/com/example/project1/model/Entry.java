package com.example.project1.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

/**
 * A short-film submission entered into the contest by a team.
 */
@Entity
@Table(name = "entry")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Entry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "title is required")
    @Column(nullable = false)
    private String title;

    @NotBlank(message = "genre is required")
    @Column(nullable = false)
    private String genre;

    @NotBlank(message = "videoLink is required")
    @Column(nullable = false, length = 1024)
    private String videoLink;

    @Builder.Default
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    // The set of judges assigned to review this entry.
    @Builder.Default
    @JsonIgnore
    @ManyToMany
    @JoinTable(
            name = "entry_judge_assignment",
            joinColumns = @JoinColumn(name = "entry_id"),
            inverseJoinColumns = @JoinColumn(name = "judge_id")
    )
    private Set<Judge> assignedJudges = new HashSet<>();

    @Builder.Default
    @JsonIgnore
    @OneToMany(mappedBy = "entry", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<ScoreCard> scoreCards = new HashSet<>();
}
