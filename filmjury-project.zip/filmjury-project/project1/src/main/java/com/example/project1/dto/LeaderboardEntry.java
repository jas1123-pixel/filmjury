package com.example.project1.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LeaderboardEntry {
    private int rank;
    private Long entryId;
    private String title;
    private String genre;
    private Double finalScore;
    private int judgeCount;
}
