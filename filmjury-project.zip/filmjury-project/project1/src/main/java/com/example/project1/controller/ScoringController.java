package com.example.project1.controller;

import com.example.project1.dto.EntryScoreResponse;
import com.example.project1.dto.LeaderboardEntry;
import com.example.project1.service.ScoringService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Tag(name = "Scoring & Leaderboard", description = "Computed average scores and the contest leaderboard")
@RestController
@RequiredArgsConstructor
public class ScoringController {

    private final ScoringService scoringService;

    @Operation(summary = "Get an entry's computed final score " +
            "(average across judges of each judge's average across criteria)")
    @GetMapping("/api/entries/{entryId}/score")
    public EntryScoreResponse getEntryScore(@PathVariable Long entryId) {
        return scoringService.computeEntryScore(entryId);
    }

    @Operation(summary = "Ranked leaderboard of every entry, highest final score first. " +
            "Optional page/size query params paginate the (already-ranked) results.")
    @GetMapping("/api/leaderboard")
    public List<LeaderboardEntry> getLeaderboard(
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size) {
        List<LeaderboardEntry> ranked = scoringService.getLeaderboard();
        if (page == null || size == null) {
            return ranked;
        }
        int from = Math.max(page, 0) * size;
        if (from >= ranked.size()) {
            return List.of();
        }
        int to = Math.min(from + size, ranked.size());
        return ranked.subList(from, to);
    }
}
