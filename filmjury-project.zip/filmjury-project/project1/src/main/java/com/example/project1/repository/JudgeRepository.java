package com.example.project1.repository;

import com.example.project1.model.Judge;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface JudgeRepository extends JpaRepository<Judge, Long> {
    Optional<Judge> findByEmail(String email);
    boolean existsByEmail(String email);
}
