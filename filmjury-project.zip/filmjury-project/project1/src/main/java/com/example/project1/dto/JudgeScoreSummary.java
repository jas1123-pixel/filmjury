package com.example.project1.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/** One judge's completed scorecard for an entry, plus their average across criteria. */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JudgeScoreSummary {
    private Long judgeId;
    private String judgeName;
    private Double averageScore;
    private List<ScoreCardResponse> criterionScores;
}
