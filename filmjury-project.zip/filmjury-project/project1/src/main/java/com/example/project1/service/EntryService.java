package com.example.project1.service;

import com.example.project1.dto.EntryRequest;
import com.example.project1.exception.ResourceNotFoundException;
import com.example.project1.model.Entry;
import com.example.project1.model.Judge;
import com.example.project1.repository.EntryRepository;
import com.example.project1.repository.JudgeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EntryService {

    private final EntryRepository entryRepository;
    private final JudgeRepository judgeRepository;

    public Entry createEntry(EntryRequest request) {
        Entry entry = Entry.builder()
                .title(request.getTitle())
                .genre(request.getGenre())
                .videoLink(request.getVideoLink())
                .build();
        return entryRepository.save(entry);
    }

    public List<Entry> getAllEntries() {
        return entryRepository.findAll();
    }

    public Entry getEntryOrThrow(Long entryId) {
        return entryRepository.findById(entryId)
                .orElseThrow(() -> new ResourceNotFoundException("Entry not found with id " + entryId));
    }

    @Transactional
    public Entry updateEntry(Long entryId, EntryRequest request) {
        Entry entry = getEntryOrThrow(entryId);
        entry.setTitle(request.getTitle());
        entry.setGenre(request.getGenre());
        entry.setVideoLink(request.getVideoLink());
        return entryRepository.save(entry);
    }

    public void deleteEntry(Long entryId) {
        Entry entry = getEntryOrThrow(entryId);
        entryRepository.delete(entry);
    }

    @Transactional
    public Entry assignJudge(Long entryId, Long judgeId) {
        Entry entry = getEntryOrThrow(entryId);
        Judge judge = judgeRepository.findById(judgeId)
                .orElseThrow(() -> new ResourceNotFoundException("Judge not found with id " + judgeId));
        entry.getAssignedJudges().add(judge);
        return entryRepository.save(entry);
    }

    @Transactional
    public void unassignJudge(Long entryId, Long judgeId) {
        Entry entry = getEntryOrThrow(entryId);
        entry.getAssignedJudges().removeIf(j -> j.getId().equals(judgeId));
        entryRepository.save(entry);
    }
}
