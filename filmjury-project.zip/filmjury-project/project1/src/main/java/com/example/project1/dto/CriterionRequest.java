package com.example.project1.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CriterionRequest {

    @NotBlank(message = "name is required")
    private String name;

    private String description;
}
