package com.example.project1.service;

import com.example.project1.dto.JudgeRequest;
import com.example.project1.exception.InvalidRequestException;
import com.example.project1.exception.ResourceNotFoundException;
import com.example.project1.model.Judge;
import com.example.project1.repository.JudgeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class JudgeService {

    private final JudgeRepository judgeRepository;

    public Judge createJudge(JudgeRequest request) {
        if (judgeRepository.existsByEmail(request.getEmail())) {
            throw new InvalidRequestException("A judge with email " + request.getEmail() + " already exists");
        }
        Judge judge = Judge.builder()
                .name(request.getName())
                .email(request.getEmail())
                .build();
        return judgeRepository.save(judge);
    }

    public List<Judge> getAllJudges() {
        return judgeRepository.findAll();
    }

    public Judge getJudgeOrThrow(Long judgeId) {
        return judgeRepository.findById(judgeId)
                .orElseThrow(() -> new ResourceNotFoundException("Judge not found with id " + judgeId));
    }

    public Judge updateJudge(Long judgeId, JudgeRequest request) {
        Judge judge = getJudgeOrThrow(judgeId);
        judge.setName(request.getName());
        judge.setEmail(request.getEmail());
        return judgeRepository.save(judge);
    }

    public void deleteJudge(Long judgeId) {
        Judge judge = getJudgeOrThrow(judgeId);
        judgeRepository.delete(judge);
    }
}
