package com.example.project1.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ScoreCardResponse {
    private Long id;
    private Long entryId;
    private Long judgeId;
    private String judgeName;
    private Long criterionId;
    private String criterionName;
    private Double score;
    private String comments;
    private LocalDateTime submittedAt;
}