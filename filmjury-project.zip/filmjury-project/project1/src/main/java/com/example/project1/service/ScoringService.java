package com.example.project1.service;

import com.example.project1.dto.EntryScoreResponse;
import com.example.project1.dto.JudgeScoreSummary;
import com.example.project1.dto.LeaderboardEntry;
import com.example.project1.dto.ScoreCardResponse;
import com.example.project1.model.Entry;
import com.example.project1.model.ScoreCard;
import com.example.project1.repository.EntryRepository;
import com.example.project1.repository.ScoreCardRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Computes derived scores. Business rule: an entry's final score is the
 * average, across every judge who has submitted a scorecard for it, of that
 * judge's own average across the criteria they scored.
 */
@Service
@RequiredArgsConstructor
public class ScoringService {

    private final EntryRepository entryRepository;
    private final ScoreCardRepository scoreCardRepository;
    private final EntryService entryService;

    public EntryScoreResponse computeEntryScore(Long entryId) {
        Entry entry = entryService.getEntryOrThrow(entryId);
        List<ScoreCard> scoreCards = scoreCardRepository.findByEntryId(entryId);

        Map<Long, List<ScoreCard>> byJudge = scoreCards.stream()
                .collect(Collectors.groupingBy(sc -> sc.getJudge().getId()));

        List<JudgeScoreSummary> perJudge = byJudge.values().stream().map(cards -> {
            double avg = cards.stream().mapToDouble(ScoreCard::getScore).average().orElse(0.0);
            List<ScoreCardResponse> lines = cards.stream().map(sc -> ScoreCardResponse.builder()
                    .id(sc.getId())
                    .entryId(entryId)
                    .judgeId(sc.getJudge().getId())
                    .judgeName(sc.getJudge().getName())
                    .criterionId(sc.getCriterion().getId())
                    .criterionName(sc.getCriterion().getName())
                    .score(sc.getScore())
                    .comments(sc.getComments())
                    .submittedAt(sc.getSubmittedAt())
                    .build()).collect(Collectors.toList());
            return JudgeScoreSummary.builder()
                    .judgeId(cards.get(0).getJudge().getId())
                    .judgeName(cards.get(0).getJudge().getName())
                    .averageScore(round(avg))
                    .criterionScores(lines)
                    .build();
        }).sorted(Comparator.comparing(JudgeScoreSummary::getJudgeId)).collect(Collectors.toList());

        double finalScore = perJudge.stream()
                .mapToDouble(JudgeScoreSummary::getAverageScore)
                .average().orElse(0.0);

        return EntryScoreResponse.builder()
                .entryId(entry.getId())
                .title(entry.getTitle())
                .finalScore(round(finalScore))
                .judgeCount(perJudge.size())
                .perJudge(perJudge)
                .build();
    }

    /** Ranked leaderboard of every entry, highest final score first. */
    public List<LeaderboardEntry> getLeaderboard() {
        List<Entry> entries = entryRepository.findAll();

        List<LeaderboardEntry> ranked = entries.stream()
                .map(e -> {
                    EntryScoreResponse scored = computeEntryScore(e.getId());
                    return LeaderboardEntry.builder()
                            .entryId(e.getId())
                            .title(e.getTitle())
                            .genre(e.getGenre())
                            .finalScore(scored.getFinalScore())
                            .judgeCount(scored.getJudgeCount())
                            .build();
                })
                .sorted(Comparator.comparing(LeaderboardEntry::getFinalScore).reversed())
                .collect(Collectors.toList());

        for (int i = 0; i < ranked.size(); i++) {
            ranked.get(i).setRank(i + 1);
        }
        return ranked;
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
