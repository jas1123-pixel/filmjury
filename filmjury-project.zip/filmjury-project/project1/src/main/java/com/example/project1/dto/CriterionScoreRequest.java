package com.example.project1.dto;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** One line item of a scorecard submission: a score for a single criterion. */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CriterionScoreRequest {

    @NotNull(message = "criterionId is required")
    private Long criterionId;

    @NotNull(message = "score is required")
    @DecimalMin(value = "0.0", message = "score must be at least 0")
    @DecimalMax(value = "10.0", message = "score must be at most 10")
    private Double score;

    private String comments;
}
