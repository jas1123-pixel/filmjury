package com.example.project1.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * A judge's full scorecard for one entry: one score per judging criterion,
 * submitted together in a single request.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScoreCardSubmissionRequest {

    @NotEmpty(message = "scores must contain at least one criterion score")
    @Valid
    private List<CriterionScoreRequest> scores;
}
