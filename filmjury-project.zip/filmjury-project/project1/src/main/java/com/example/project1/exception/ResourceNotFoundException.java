package com.example.project1.exception;

/** Thrown when a requested Entry, Judge, Criterion or ScoreCard does not exist. */
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
