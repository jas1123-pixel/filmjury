package com.example.project1.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

/**
 * A fixed judging criterion (e.g. Story, Direction, Cinematography) that
 * every judge scores every entry against.
 */
@Entity
@Table(name = "criterion")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Criterion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "name is required")
    @Column(nullable = false, unique = true)
    private String name;

    private String description;

    @Builder.Default
    @JsonIgnore
    @OneToMany(mappedBy = "criterion", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<ScoreCard> scoreCards = new HashSet<>();
}
