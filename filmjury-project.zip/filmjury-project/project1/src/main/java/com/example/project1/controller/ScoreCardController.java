package com.example.project1.controller;

import com.example.project1.dto.ScoreCardResponse;
import com.example.project1.dto.ScoreCardSubmissionRequest;
import com.example.project1.service.ScoreCardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Scorecards", description = "Judges submit and view scorecards for entries")
@RestController
@RequiredArgsConstructor
public class ScoreCardController {

    private final ScoreCardService scoreCardService;

    @Operation(summary = "Judge submits their scorecard (one score per criterion) for an entry. " +
            "Fails with 409 if this judge already scored this entry.")
    @PostMapping("/api/entries/{entryId}/judges/{judgeId}/scorecards")
    public ResponseEntity<List<ScoreCardResponse>> submitScoreCard(
            @PathVariable Long entryId,
            @PathVariable Long judgeId,
            @Valid @RequestBody ScoreCardSubmissionRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(scoreCardService.submitScoreCard(entryId, judgeId, request));
    }

    @Operation(summary = "Get every scorecard line submitted for an entry, across all judges")
    @GetMapping("/api/entries/{entryId}/scorecards")
    public List<ScoreCardResponse> getScoreCardsForEntry(@PathVariable Long entryId) {
        return scoreCardService.getScoreCardsForEntry(entryId);
    }

    @Operation(summary = "Get a single judge's scorecard for an entry")
    @GetMapping("/api/entries/{entryId}/judges/{judgeId}/scorecards")
    public List<ScoreCardResponse> getScoreCardForJudge(@PathVariable Long entryId, @PathVariable Long judgeId) {
        return scoreCardService.getScoreCardForJudgeOnEntry(entryId, judgeId);
    }
}
