package com.example.project1.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * An entry's computed final score: the average, across every judge who has
 * submitted a scorecard, of that judge's own average across all criteria.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EntryScoreResponse {
    private Long entryId;
    private String title;
    private Double finalScore;
    private int judgeCount;
    private List<JudgeScoreSummary> perJudge;
}
