package com.example.project1.exception;

/** Thrown for business-rule violations that are not simple bean-validation failures. */
public class InvalidRequestException extends RuntimeException {
    public InvalidRequestException(String message) {
        super(message);
    }
}
