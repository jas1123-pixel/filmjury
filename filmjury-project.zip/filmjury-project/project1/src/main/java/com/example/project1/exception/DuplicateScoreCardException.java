package com.example.project1.exception;

/**
 * Thrown when a judge attempts to submit a second scorecard for an entry
 * they have already scored. Enforced in the service layer (not just the
 * database unique constraint) so the caller gets a clear, immediate error.
 */
public class DuplicateScoreCardException extends RuntimeException {
    public DuplicateScoreCardException(String message) {
        super(message);
    }
}
