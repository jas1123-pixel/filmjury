const API = '/api';

// ---------------------------------------------------------------- tabs ----
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(btn.dataset.tab).classList.add('active');
    if (btn.dataset.tab === 'leaderboard') loadLeaderboard();
    if (btn.dataset.tab === 'assign' || btn.dataset.tab === 'score') {
      loadEntryOptions(); loadJudgeOptions();
    }
  });
});

// -------------------------------------------------------------- helpers ---
async function api(path, options = {}) {
  const res = await fetch(API + path, {
    headers: { 'Content-Type': 'application/json' },
    ...options
  });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) {
    const msg = (data && (data.message || data.error)) || `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return data;
}

function showMsg(elId, text, isError) {
  const el = document.getElementById(elId);
  el.textContent = text;
  el.className = 'msg ' + (isError ? 'error' : 'success');
  setTimeout(() => { el.textContent = ''; el.className = 'msg'; }, 4000);
}

function opt(value, label) {
  const o = document.createElement('option');
  o.value = value; o.textContent = label;
  return o;
}

// -------------------------------------------------------------- entries ---
async function loadEntries() {
  const entries = await api('/entries');
  const body = document.getElementById('entryTableBody');
  body.innerHTML = '';
  entries.forEach(e => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${e.id}</td><td>${escapeHtml(e.title)}</td><td>${escapeHtml(e.genre)}</td>
      <td><a href="${e.videoLink}" target="_blank">watch</a></td>
      <td><button class="danger" onclick="deleteEntry(${e.id})">Delete</button></td>`;
    body.appendChild(tr);
  });
}

async function deleteEntry(id) {
  if (!confirm('Delete this entry?')) return;
  await api(`/entries/${id}`, { method: 'DELETE' });
  loadEntries();
}

document.getElementById('entryForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/entries', {
      method: 'POST',
      body: JSON.stringify({
        title: document.getElementById('entryTitle').value,
        genre: document.getElementById('entryGenre').value,
        videoLink: document.getElementById('entryVideoLink').value
      })
    });
    e.target.reset();
    showMsg('entryMsg', 'Entry submitted.', false);
    loadEntries();
  } catch (err) { showMsg('entryMsg', err.message, true); }
});

// --------------------------------------------------------------- judges ---
async function loadJudges() {
  const judges = await api('/judges');
  const body = document.getElementById('judgeTableBody');
  body.innerHTML = '';
  judges.forEach(j => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${j.id}</td><td>${escapeHtml(j.name)}</td><td>${escapeHtml(j.email)}</td>
      <td><button class="danger" onclick="deleteJudge(${j.id})">Delete</button></td>`;
    body.appendChild(tr);
  });
}

async function deleteJudge(id) {
  if (!confirm('Delete this judge?')) return;
  await api(`/judges/${id}`, { method: 'DELETE' });
  loadJudges();
}

document.getElementById('judgeForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/judges', {
      method: 'POST',
      body: JSON.stringify({
        name: document.getElementById('judgeName').value,
        email: document.getElementById('judgeEmail').value
      })
    });
    e.target.reset();
    showMsg('judgeMsg', 'Judge registered.', false);
    loadJudges();
  } catch (err) { showMsg('judgeMsg', err.message, true); }
});

// ------------------------------------------------------------- criteria ---
async function loadCriteria() {
  const criteria = await api('/criteria');
  const body = document.getElementById('criterionTableBody');
  body.innerHTML = '';
  criteria.forEach(c => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${c.id}</td><td>${escapeHtml(c.name)}</td><td>${escapeHtml(c.description || '')}</td>
      <td><button class="danger" onclick="deleteCriterion(${c.id})">Delete</button></td>`;
    body.appendChild(tr);
  });
  return criteria;
}

async function deleteCriterion(id) {
  if (!confirm('Delete this criterion?')) return;
  await api(`/criteria/${id}`, { method: 'DELETE' });
  loadCriteria();
}

document.getElementById('criterionForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/criteria', {
      method: 'POST',
      body: JSON.stringify({
        name: document.getElementById('criterionName').value,
        description: document.getElementById('criterionDesc').value
      })
    });
    e.target.reset();
    showMsg('criterionMsg', 'Criterion added.', false);
    loadCriteria();
  } catch (err) { showMsg('criterionMsg', err.message, true); }
});

// ---------------------------------------------------------- assign judge --
async function loadEntryOptions() {
  const entries = await api('/entries');
  ['assignEntry', 'scoreEntry', 'viewEntry'].forEach(id => {
    const sel = document.getElementById(id);
    sel.innerHTML = '';
    entries.forEach(e => sel.appendChild(opt(e.id, `#${e.id} — ${e.title}`)));
  });
  if (document.getElementById('scoreEntry').options.length) buildCriterionScoreInputs();
}

async function loadJudgeOptions() {
  const judges = await api('/judges');
  ['assignJudge', 'scoreJudge', 'viewJudge'].forEach(id => {
    const sel = document.getElementById(id);
    sel.innerHTML = '';
    judges.forEach(j => sel.appendChild(opt(j.id, `#${j.id} — ${j.name}`)));
  });
}

document.getElementById('assignForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const entryId = document.getElementById('assignEntry').value;
  const judgeId = document.getElementById('assignJudge').value;
  try {
    await api(`/entries/${entryId}/judges/${judgeId}`, { method: 'POST' });
    showMsg('assignMsg', `Judge #${judgeId} assigned to entry #${entryId}.`, false);
  } catch (err) { showMsg('assignMsg', err.message, true); }
});

// ------------------------------------------------------ submit scorecard --
document.getElementById('scoreEntry').addEventListener('change', buildCriterionScoreInputs);

async function buildCriterionScoreInputs() {
  const criteria = await api('/criteria');
  const container = document.getElementById('criterionScoreInputs');
  container.innerHTML = '';
  criteria.forEach(c => {
    const row = document.createElement('div');
    row.className = 'criterion-score-row';
    row.innerHTML = `
      <label>${escapeHtml(c.name)}</label>
      <input type="number" min="0" max="10" step="0.5" placeholder="0-10"
             data-criterion-id="${c.id}" class="score-input" required>
      <input type="text" placeholder="comment (optional)" class="comment-input">`;
    container.appendChild(row);
  });
}

document.getElementById('scoreForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const entryId = document.getElementById('scoreEntry').value;
  const judgeId = document.getElementById('scoreJudge').value;
  const rows = document.querySelectorAll('#criterionScoreInputs .criterion-score-row');
  const scores = Array.from(rows).map(row => ({
    criterionId: Number(row.querySelector('.score-input').dataset.criterionId),
    score: Number(row.querySelector('.score-input').value),
    comments: row.querySelector('.comment-input').value
  }));
  try {
    await api(`/entries/${entryId}/judges/${judgeId}/scorecards`, {
      method: 'POST',
      body: JSON.stringify({ scores })
    });
    showMsg('scoreMsg', 'Scorecard submitted.', false);
    e.target.reset();
  } catch (err) { showMsg('scoreMsg', err.message, true); }
});

document.getElementById('viewScoreForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const entryId = document.getElementById('viewEntry').value;
  const judgeId = document.getElementById('viewJudge').value;
  const body = document.getElementById('viewScoreTableBody');
  body.innerHTML = '';
  try {
    const lines = await api(`/entries/${entryId}/judges/${judgeId}/scorecards`);
    if (!lines.length) {
      body.innerHTML = '<tr><td colspan="3">No scorecard submitted yet.</td></tr>';
    }
    lines.forEach(l => {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${escapeHtml(l.criterionName)}</td><td>${l.score}</td><td>${escapeHtml(l.comments || '')}</td>`;
      body.appendChild(tr);
    });
  } catch (err) { body.innerHTML = `<tr><td colspan="3">${escapeHtml(err.message)}</td></tr>`; }
});

// ----------------------------------------------------------- leaderboard --
async function loadLeaderboard() {
  const rows = await api('/leaderboard');
  const body = document.getElementById('leaderboardTableBody');
  body.innerHTML = '';
  rows.forEach(r => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td class="${r.rank === 1 ? 'rank-1' : ''}">${r.rank}</td>
      <td>${escapeHtml(r.title)}</td><td>${escapeHtml(r.genre)}</td>
      <td>${r.finalScore}</td><td>${r.judgeCount}</td>
      <td><button class="secondary" onclick="showEntryDetail(${r.entryId})">View</button></td>`;
    body.appendChild(tr);
  });
}
document.getElementById('refreshLeaderboard').addEventListener('click', loadLeaderboard);

async function showEntryDetail(entryId) {
  const detail = await api(`/entries/${entryId}/score`);
  const el = document.getElementById('entryScoreDetail');
  el.style.display = 'block';
  el.innerHTML = `<h3>${escapeHtml(detail.title)} — final score ${detail.finalScore} (${detail.judgeCount} judge(s))</h3>` +
    detail.perJudge.map(j => `
      <p><strong>${escapeHtml(j.judgeName)}</strong> — avg ${j.averageScore}<br>
      ${j.criterionScores.map(c => `${escapeHtml(c.criterionName)}: ${c.score}`).join(' &middot; ')}</p>
    `).join('');
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str).replace(/[&<>"']/g, m => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[m]));
}

// ------------------------------------------------------------------ init --
loadEntries();
loadJudges();
loadCriteria();
loadEntryOptions();
loadJudgeOptions();
