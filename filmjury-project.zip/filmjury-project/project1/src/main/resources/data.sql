-- Seed a fixed set of judging criteria so the app is usable immediately.
INSERT IGNORE INTO criterion (id, name, description) VALUES (1, 'Story', 'Originality and strength of the narrative');
INSERT IGNORE INTO criterion (id, name, description) VALUES (2, 'Direction', 'Overall directorial vision and execution');
INSERT IGNORE INTO criterion (id, name, description) VALUES (3, 'Cinematography', 'Visual composition, lighting and camera work');
INSERT IGNORE INTO criterion (id, name, description) VALUES (4, 'Editing', 'Pacing, continuity and post-production quality');

